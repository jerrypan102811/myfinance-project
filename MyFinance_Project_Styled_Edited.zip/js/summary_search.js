function getMonthName(monthIndex) {
  return [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ][monthIndex];
}

function updateMonthlySummary() {
  const transactions = JSON.parse(localStorage.getItem("transactions") || "[]");
  const monthlyTotals = new Array(12).fill(0);
  transactions.forEach(tx => {
    const date = new Date(tx.date);
    if (!isNaN(date)) {
      const month = date.getMonth();
      monthlyTotals[month] += parseFloat(tx.amount || 0);
    }
  });

  const tbody = document.getElementById("monthly-summary-body");
  if (!tbody) return;
  tbody.innerHTML = "";
  for (let i = 0; i < 12; i++) {
    tbody.innerHTML += `<tr><td>${getMonthName(i)}</td><td>$${monthlyTotals[i].toFixed(2)}</td></tr>`;
  }
}

function searchTransactions() {
  const transactions = JSON.parse(localStorage.getItem("transactions") || "[]");
  const keyword = document.getElementById("search").value.toLowerCase();
  const result = transactions.filter(tx =>
    (tx.category && tx.category.toLowerCase().includes(keyword)) ||
    (tx.description && tx.description.toLowerCase().includes(keyword))
  );
  const tbody = document.getElementById("search-body");
  if (!tbody) return;
  tbody.innerHTML = "";
  result.forEach(tx => {
    tbody.innerHTML += `<tr>
      <td>${tx.date}</td>
      <td>${tx.category}</td>
      <td>$${parseFloat(tx.amount).toFixed(2)}</td>
      <td>${tx.description}</td>
    </tr>`;
  });
}